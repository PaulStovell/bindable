﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bindable.Aspects")]
[assembly: AssemblyDescription("A set of PostSharp aspects used in Bindable LINQ and other libraries.")]
[assembly: Guid("91dd9df0-2866-4b25-ad3b-fee06ce37b70")]